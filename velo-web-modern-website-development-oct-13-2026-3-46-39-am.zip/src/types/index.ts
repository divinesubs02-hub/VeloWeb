export interface Project {
  id: string;
  title: string;
  category: 'Business' | 'Landing Page' | 'Portfolio' | 'E-commerce' | 'Company' | 'Custom';
  shortDescription: string;
  fullOverview: string;
  designHighlights: string[];
  features: string[];
  technologies: string[];
  imageUrl: string;
  liveUrl: string;
  featured?: boolean;
}

export interface Service {
  id: string;
  title: string;
  tagline: string;
  description: string;
  deliverables: string[];
  idealFor: string;
}

export interface Package {
  id: string;
  name: string;
  description: string;
  badge?: string;
  highlights: string[];
  pricingNote: string;
}

export interface AddOn {
  id: string;
  title: string;
  description: string;
  details: string;
  chargeNotice: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface BrandConfig {
  name: string;
  tagline: string;
  positioning: string;
  coreMessage: string;
  availability: string;
  whatsappNumber: string;
  whatsappLink: string;
  instagramHandle: string;
  instagramUrl: string;
  facebookName: string;
  facebookUrl: string;
  domainPolicyShort: string;
  domainPolicyFull: string;
  googleSpreadsheetId?: string;
  googleSpreadsheetUrl?: string;
}

export interface SiteContent {
  brand: BrandConfig;
  services: Service[];
  projects: Project[];
  packages: Package[];
  addOns: AddOn[];
  faqs: FaqItem[];
  technologies: string[];
}

export interface Inquiry {
  id: string;
  name: string;
  contactMethod: string;
  projectType: string;
  budgetRange?: string;
  projectDetails: string;
  createdAt: string;
  status: 'new' | 'contacted' | 'completed';
}
