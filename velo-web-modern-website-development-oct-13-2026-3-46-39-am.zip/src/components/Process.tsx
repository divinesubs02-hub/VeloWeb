import React from 'react';
import { MessageSquare, LayoutTemplate, Code2, Rocket, AlertCircle, ArrowUpRight } from 'lucide-react';
import { BrandConfig } from '../types';

interface ProcessProps {
  brand: BrandConfig;
}

export const Process: React.FC<ProcessProps> = ({ brand }) => {
  const steps = [
    {
      number: '01',
      title: 'Tell Me Your Idea',
      description: 'Send me your requirements, examples, and what you want your website to accomplish.',
      icon: <MessageSquare className="w-5 h-5 text-cyan-400" />,
      detail: 'Share reference links, brand colors, pages needed, and desired features directly on WhatsApp.'
    },
    {
      number: '02',
      title: 'Plan & Design',
      description: 'I turn your requirements into a clean, modern website structure and design.',
      icon: <LayoutTemplate className="w-5 h-5 text-cyan-400" />,
      detail: 'We establish visual layout, typographic hierarchy, responsive sections, and navigation flow.'
    },
    {
      number: '03',
      title: 'Build',
      description: 'I develop the website and make sure it works smoothly across desktop, tablet, and mobile.',
      icon: <Code2 className="w-5 h-5 text-cyan-400" />,
      detail: 'Clean, modern code engineered for speed, cross-browser compatibility, and smooth responsiveness.'
    },
    {
      number: '04',
      title: 'Launch',
      description: 'Once everything is approved, your website is ready to go live.',
      icon: <Rocket className="w-5 h-5 text-cyan-400" />,
      detail: 'Final review, assets check, and seamless deployment to your production environment.'
    }
  ];

  return (
    <section id="process" className="py-24 relative bg-[#090D15] border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
            Workflow & Delivery
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            How It Works
          </h2>
          <p className="mt-3 text-base text-slate-400 leading-relaxed">
            A simple, transparent 4-step process designed to take your idea from concept to a live professional website without confusion or delays.
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step) => (
            <div
              key={step.number}
              className="relative rounded-2xl bg-[#0B0F17] border border-slate-800/90 p-7 flex flex-col justify-between hover:border-cyan-500/40 transition-all duration-300"
            >
              <div>
                {/* Step Number & Icon */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                    {step.icon}
                  </div>
                  <span className="text-2xl font-extrabold font-mono text-slate-700">
                    {step.number}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white mb-2">
                  {step.title}
                </h3>

                <p className="text-sm font-medium text-slate-300 leading-relaxed mb-4">
                  "{step.description}"
                </p>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {step.detail}
                </p>
              </div>

              <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span>Step {step.number} of 04</span>
                <span className="text-cyan-400">Phase {step.number}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Important Domain Note Banner */}
        <div className="mt-12 p-4 rounded-xl bg-[#070B12] border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3 text-xs text-slate-300">
            <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              <strong className="text-white">Domain note:</strong> Domain purchase or domain setup can be provided separately if required. Additional charges apply.
            </span>
          </div>

          <a
            href={brand.whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <span>Have an idea? Let's talk</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </section>
  );
};
