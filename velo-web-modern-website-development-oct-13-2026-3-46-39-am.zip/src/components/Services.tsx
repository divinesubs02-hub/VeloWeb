import React from 'react';
import { Layout, Globe, Briefcase, ShoppingBag, Terminal, Sparkles, ArrowRight, Check } from 'lucide-react';
import { Service, BrandConfig } from '../types';

interface ServicesProps {
  services: Service[];
  brand: BrandConfig;
}

export const Services: React.FC<ServicesProps> = ({ services, brand }) => {
  // Service category icon mapper
  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'srv-business':
        return <Briefcase className="w-5 h-5 text-cyan-400" />;
      case 'srv-landing':
        return <Sparkles className="w-5 h-5 text-cyan-400" />;
      case 'srv-portfolio':
        return <Layout className="w-5 h-5 text-cyan-400" />;
      case 'srv-company':
        return <Globe className="w-5 h-5 text-cyan-400" />;
      case 'srv-ecommerce':
        return <ShoppingBag className="w-5 h-5 text-cyan-400" />;
      case 'srv-custom':
      default:
        return <Terminal className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="services" className="py-24 relative border-t border-slate-900 bg-[#07090E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-2xl">
            <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
              Capabilities & Focus
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
              What We Build
            </h2>
            <p className="mt-4 text-base text-slate-400 leading-relaxed">
              Velo Web specializes specifically in website creation and development. Clean code, modern UI, and responsive performance — built to turn your vision into reality.
            </p>
          </div>

          <div className="text-xs text-slate-500 max-w-xs md:text-right">
            Pure website development. No marketing jargon, no SEO upsells, no bloated retainers.
          </div>
        </div>

        {/* 6 Services Grid (Asymmetric & Balanced Bento layout) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const encodedMessage = encodeURIComponent(
              `Hi Velo Web, I would like to discuss a project for: ${service.title}`
            );
            const whatsappProjectUrl = `${brand.whatsappLink}?text=${encodedMessage}`;

            return (
              <div
                key={service.id}
                className="group relative rounded-2xl bg-[#0B0F17] border border-slate-800/90 p-6 sm:p-7 flex flex-col justify-between hover:border-cyan-500/40 hover:bg-[#0E1420] transition-all duration-300 shadow-sm hover:shadow-lg hover:shadow-cyan-950/20"
              >
                <div>
                  {/* Card Header & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center group-hover:border-cyan-500/50 group-hover:scale-105 transition-all">
                      {getServiceIcon(service.id)}
                    </div>
                    <span className="text-xs font-mono text-slate-500">
                      0{index + 1}
                    </span>
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {service.title}
                  </h3>
                  <div className="text-xs font-medium text-cyan-400/90 mt-1 mb-3">
                    {service.tagline}
                  </div>

                  <p className="text-sm text-slate-400 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Key Deliverables */}
                  <div className="space-y-2 mb-6 pt-4 border-t border-slate-800/80">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Included In Build
                    </div>
                    {service.deliverables.map((item, dIdx) => (
                      <div key={dIdx} className="flex items-center gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer & Action */}
                <div className="pt-4 border-t border-slate-800/80 mt-auto">
                  <div className="text-[11px] text-slate-500 mb-3">
                    <span className="font-medium text-slate-400">Ideal for: </span>
                    {service.idealFor}
                  </div>

                  <a
                    href={whatsappProjectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 group-hover:text-cyan-300 hover:underline underline-offset-4 transition-colors"
                  >
                    <span>Discuss this website</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
