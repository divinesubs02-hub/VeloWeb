import React, { useState } from 'react';
import { MessageCircle, Instagram, Facebook, Send, ArrowUpRight, CheckCircle2, Clock, Sparkles } from 'lucide-react';
import { BrandConfig, Inquiry } from '../types';
import { googleSheetsService } from '../services/googleSheets';

interface ContactProps {
  brand: BrandConfig;
  onInquirySubmitted?: () => void;
  googleToken?: string | null;
}

export const Contact: React.FC<ContactProps> = ({ brand, onInquirySubmitted, googleToken }) => {
  const [formData, setFormData] = useState({
    name: '',
    contactMethod: '',
    projectType: 'Business Website',
    budgetRange: 'Custom Quote',
    projectDetails: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const projectTypes = [
    'Business Website',
    'Landing Page',
    'Portfolio Website',
    'Company Website',
    'E-commerce Website',
    'Custom Website'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.contactMethod || !formData.projectDetails) {
      setErrorMessage('Please fill in your name, contact method, and project details.');
      return;
    }
    setErrorMessage('');
    setIsSubmitting(true);

    try {
      // 1. Save to backend database API
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (!res.ok) {
        throw new Error('Failed to save inquiry to database');
      }

      const resData = await res.json();
      const savedInquiry: Inquiry = resData.inquiry;

      // 2. If Google Sheets backend is connected and token available, append to sheet
      if (googleToken && brand.googleSpreadsheetId && savedInquiry) {
        googleSheetsService.appendInquiryToSpreadsheet(
          googleToken,
          brand.googleSpreadsheetId,
          savedInquiry
        ).catch(err => console.warn('Google Sheets append error:', err));
      }

      setSubmitted(true);
      if (onInquirySubmitted) onInquirySubmitted();
    } catch (err: any) {
      console.warn('Backend log note:', err);
      setSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDirectWhatsAppUrl = () => {
    const text = encodeURIComponent(
      `Hi Velo Web,\n\nName: ${formData.name || 'Client'}\nProject Type: ${formData.projectType}\nDetails: ${formData.projectDetails || 'I would like to start a website project.'}\nContact: ${formData.contactMethod}`
    );
    return `${brand.whatsappLink}?text=${text}`;
  };

  return (
    <section id="contact" className="py-24 relative bg-[#090D15] border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Final CTA Banner */}
        <div className="relative rounded-3xl bg-gradient-to-b from-[#0F172A] to-[#0B0F17] border border-cyan-500/30 p-6 sm:p-10 md:p-12 lg:p-14 text-center overflow-hidden mb-20 md:mb-24 shadow-2xl shadow-cyan-950/20">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-28 bg-cyan-400/10 blur-[80px] pointer-events-none" />

          <div className="relative z-10 max-w-3xl mx-auto space-y-5 sm:space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/40 text-xs font-semibold text-cyan-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Let's Build Something Great</span>
            </div>

            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
              Ready to Build Your Website?
            </h2>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
              Tell Velo Web what you need, and let's turn your idea into a professional website.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <a
                href={brand.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] hover:from-[#38BDF8] hover:to-[#0284C7] rounded-xl shadow-lg shadow-cyan-500/25 transition-all"
              >
                <span>Start a Project</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>

              <a
                href="#work"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-all"
              >
                <span>View Our Work</span>
              </a>
            </div>
          </div>
        </div>

        {/* Contact Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
            Get In Touch
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Let's Talk About Your Website.
          </h2>
          <p className="mt-3 text-base text-slate-400">
            Reach out through WhatsApp or send a message directly below.
          </p>
        </div>

        {/* Contact Channels Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Direct Channels (WhatsApp, Instagram, Facebook) */}
          <div className="lg:col-span-5 space-y-6">
            {/* WhatsApp Featured Card */}
            <div className="rounded-2xl bg-[#0B0F17] border border-cyan-500/40 p-7 shadow-lg shadow-cyan-950/20">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-950/60 border border-emerald-700/50 flex items-center justify-center text-emerald-400">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-mono text-emerald-400 uppercase">Direct Channel</div>
                  <h3 className="text-lg font-bold text-white">WhatsApp</h3>
                </div>
              </div>

              <div className="text-xl font-mono font-bold text-white mb-2">
                {brand.whatsappNumber}
              </div>

              <p className="text-xs text-slate-400 mb-6">
                Fastest response. Send your idea, reference websites, or requirements anytime.
              </p>

              <a
                href={brand.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] hover:from-[#38BDF8] hover:to-[#0284C7] rounded-xl shadow-md transition-all"
              >
                <span>Chat on WhatsApp</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* Social Channels (Instagram & Facebook) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Instagram Card */}
              <a
                href={brand.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group rounded-2xl bg-[#0B0F17] border border-slate-800 p-5 hover:border-cyan-500/40 hover:bg-[#0E1420] transition-all"
              >
                <div className="w-10 h-10 rounded-xl bg-pink-950/40 border border-pink-800/40 flex items-center justify-center text-pink-400 mb-3 group-hover:scale-105 transition-transform">
                  <Instagram className="w-5 h-5" />
                </div>
                <div className="text-xs text-slate-500 font-mono">Instagram</div>
                <div className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {brand.instagramHandle}
                </div>
                <div className="mt-2 text-[11px] text-cyan-400 flex items-center gap-1">
                  <span>Follow on Instagram</span>
                  <ArrowUpRight className="w-3 h-3" />
                </div>
              </a>

              {/* Facebook Card */}
              <a
                href={brand.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group rounded-2xl bg-[#0B0F17] border border-slate-800 p-5 hover:border-cyan-500/40 hover:bg-[#0E1420] transition-all"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-950/40 border border-blue-800/40 flex items-center justify-center text-blue-400 mb-3 group-hover:scale-105 transition-transform">
                  <Facebook className="w-5 h-5" />
                </div>
                <div className="text-xs text-slate-500 font-mono">Facebook</div>
                <div className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {brand.facebookName}
                </div>
                <div className="mt-2 text-[11px] text-cyan-400 flex items-center gap-1">
                  <span>View on Facebook</span>
                  <ArrowUpRight className="w-3 h-3" />
                </div>
              </a>
            </div>
          </div>

          {/* Right Column: Direct Website Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-[#0B0F17] border border-slate-800 p-8">
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white">
                  Send a Quick Project Inquiry
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Your inquiry is saved to our database and can immediately be sent to WhatsApp with one click.
                </p>
              </div>

              {submitted ? (
                <div className="py-8 text-center space-y-4 animate-in fade-in duration-200">
                  <div className="w-12 h-12 rounded-full bg-emerald-950/60 border border-emerald-600/60 flex items-center justify-center text-emerald-400 mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-white">
                    Inquiry Received!
                  </h4>
                  <p className="text-xs text-slate-300 max-w-sm mx-auto">
                    Thank you, <strong className="text-white">{formData.name}</strong>. Your project details have been logged in the Velo Web database.
                  </p>
                  <div className="pt-2">
                    <a
                      href={getDirectWhatsAppUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] rounded-xl shadow-md"
                    >
                      <span>Also Open in WhatsApp Now</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </div>
                  <div>
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setFormData({
                          name: '',
                          contactMethod: '',
                          projectType: 'Business Website',
                          budgetRange: 'Custom Quote',
                          projectDetails: ''
                        });
                      }}
                      className="text-xs text-slate-500 hover:text-slate-300 underline"
                    >
                      Submit another inquiry
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {errorMessage && (
                    <div className="p-3 rounded-lg bg-rose-950/50 border border-rose-800 text-rose-300 text-xs">
                      {errorMessage}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Your Name / Business Name *
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. John Doe / Apex Advisory"
                        required
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        WhatsApp or Email *
                      </label>
                      <input
                        type="text"
                        value={formData.contactMethod}
                        onChange={(e) => setFormData({ ...formData, contactMethod: e.target.value })}
                        placeholder="e.g. +92 300 1234567 or email@domain.com"
                        required
                        className="w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Website Type
                    </label>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                    >
                      {projectTypes.map((pt) => (
                        <option key={pt} value={pt} className="bg-slate-900">
                          {pt}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Project Details & Requirements *
                    </label>
                    <textarea
                      rows={3}
                      value={formData.projectDetails}
                      onChange={(e) => setFormData({ ...formData, projectDetails: e.target.value })}
                      placeholder="Briefly describe what your website needs (pages, design style, reference websites you like)..."
                      required
                      className="w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors resize-none"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                    <span className="text-[11px] text-slate-400">
                      ⚡ Quick response guaranteed directly on WhatsApp
                    </span>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] hover:from-[#38BDF8] hover:to-[#0284C7] rounded-lg shadow-md transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? 'Saving...' : 'Send Inquiry'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
