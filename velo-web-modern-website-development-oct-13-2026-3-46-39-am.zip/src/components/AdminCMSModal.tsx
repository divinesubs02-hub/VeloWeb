import React, { useState, useEffect } from 'react';
import { 
  X, Save, RotateCcw, Plus, Trash2, Edit3, 
  MessageSquare, Layout, Package as PackageIcon, HelpCircle, 
  Settings, ExternalLink, Database, CheckCircle, Table,
  ArrowDownToLine, ArrowUpFromLine, RefreshCw, LogIn, LogOut, Check
} from 'lucide-react';
import { User } from 'firebase/auth';
import { SiteContent, Project, Package, FaqItem, Inquiry } from '../types';
import { googleSignIn, googleLogout, initGoogleAuth } from '../services/googleAuth';
import { googleSheetsService, SpreadsheetInfo } from '../services/googleSheets';

interface AdminCMSModalProps {
  isOpen: boolean;
  content: SiteContent;
  onClose: () => void;
  onSaveContent: (newContent: SiteContent) => Promise<boolean>;
  onResetContent: () => Promise<void>;
  googleUser: User | null;
  googleToken: string | null;
  onGoogleAuthChange: (user: User | null, token: string | null) => void;
}

export const AdminCMSModal: React.FC<AdminCMSModalProps> = ({
  isOpen,
  content,
  onClose,
  onSaveContent,
  onResetContent,
  googleUser,
  googleToken,
  onGoogleAuthChange,
}) => {
  const [activeTab, setActiveTab] = useState<'brand' | 'projects' | 'packages' | 'inquiries' | 'sheets' | 'faqs'>('brand');
  const [draftContent, setDraftContent] = useState<SiteContent>(content);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [inquiriesLoading, setInquiriesLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // Google Sheets state
  const [sheetsLoading, setSheetsLoading] = useState(false);
  const [sheetsError, setSheetsError] = useState<string | null>(null);
  const [customSheetInput, setCustomSheetInput] = useState('');
  const [connectedSheetInfo, setConnectedSheetInfo] = useState<SpreadsheetInfo | null>(null);

  useEffect(() => {
    setDraftContent(content);
  }, [content]);

  useEffect(() => {
    if (isOpen && activeTab === 'inquiries') {
      fetchInquiries();
    }
  }, [isOpen, activeTab]);

  // Check if spreadsheet metadata is already stored in brand config
  useEffect(() => {
    if (googleToken && draftContent.brand.googleSpreadsheetId && !connectedSheetInfo) {
      googleSheetsService.getSpreadsheetMetadata(googleToken, draftContent.brand.googleSpreadsheetId)
        .then(info => setConnectedSheetInfo(info))
        .catch(err => console.warn('Could not verify existing sheet:', err));
    }
  }, [googleToken, draftContent.brand.googleSpreadsheetId]);

  const fetchInquiries = async () => {
    setInquiriesLoading(true);
    try {
      const res = await fetch('/api/inquiries');
      if (res.ok) {
        const data = await res.json();
        setInquiries(data);
      }
    } catch (err) {
      console.warn('Failed to fetch inquiries:', err);
    } finally {
      setInquiriesLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    const success = await onSaveContent(draftContent);
    setIsSaving(false);
    if (success) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  const handleReset = async () => {
    if (window.confirm('Reset all content back to factory defaults? Any custom modifications will be replaced.')) {
      await onResetContent();
    }
  };

  // Google Auth Actions
  const handleGoogleLogin = async () => {
    setSheetsError(null);
    setSheetsLoading(true);
    try {
      const res = await googleSignIn();
      if (res) {
        onGoogleAuthChange(res.user, res.accessToken);
        setStatusMessage(`Signed in as ${res.user.displayName || res.user.email}`);
      }
    } catch (err: any) {
      setSheetsError(err.message || 'Google sign-in failed');
    } finally {
      setSheetsLoading(false);
    }
  };

  const handleGoogleSignOut = async () => {
    await googleLogout();
    onGoogleAuthChange(null, null);
    setConnectedSheetInfo(null);
  };

  // Google Sheets Backend Operations
  const handleCreateNewSheet = async () => {
    if (!googleToken) {
      setSheetsError('Please sign in with Google first.');
      return;
    }
    setSheetsLoading(true);
    setSheetsError(null);
    try {
      const info = await googleSheetsService.createVeloSpreadsheet(googleToken, draftContent, inquiries);
      setConnectedSheetInfo(info);
      const updated = {
        ...draftContent,
        brand: {
          ...draftContent.brand,
          googleSpreadsheetId: info.id,
          googleSpreadsheetUrl: info.url
        }
      };
      setDraftContent(updated);
      await onSaveContent(updated);
      setStatusMessage(`Google Sheet created: "${info.title}"`);
    } catch (err: any) {
      setSheetsError(err.message || 'Failed to create Google Sheet');
    } finally {
      setSheetsLoading(false);
    }
  };

  const handleConnectExistingSheet = async () => {
    if (!googleToken) {
      setSheetsError('Please sign in with Google first.');
      return;
    }
    if (!customSheetInput.trim()) {
      setSheetsError('Please enter a Google Sheet URL or Spreadsheet ID.');
      return;
    }
    setSheetsLoading(true);
    setSheetsError(null);
    try {
      const info = await googleSheetsService.getSpreadsheetMetadata(googleToken, customSheetInput);
      setConnectedSheetInfo(info);
      const updated = {
        ...draftContent,
        brand: {
          ...draftContent.brand,
          googleSpreadsheetId: info.id,
          googleSpreadsheetUrl: info.url
        }
      };
      setDraftContent(updated);
      await onSaveContent(updated);
      setStatusMessage(`Connected to Google Sheet: "${info.title}"`);
      setCustomSheetInput('');
    } catch (err: any) {
      setSheetsError(err.message || 'Could not connect to Google Sheet. Check ID and permissions.');
    } finally {
      setSheetsLoading(false);
    }
  };

  const handlePushToGoogleSheet = async () => {
    if (!googleToken || !connectedSheetInfo) return;
    if (!window.confirm(`Export current website data into Google Sheet "${connectedSheetInfo.title}"? This will overwrite the tabs in the spreadsheet with your current site content.`)) {
      return;
    }
    setSheetsLoading(true);
    setSheetsError(null);
    try {
      await googleSheetsService.syncAllDataToSpreadsheet(googleToken, connectedSheetInfo.id, draftContent, inquiries);
      setStatusMessage('Data exported to Google Sheet successfully!');
    } catch (err: any) {
      setSheetsError(err.message || 'Failed to sync to Google Sheet');
    } finally {
      setSheetsLoading(false);
    }
  };

  const handlePullFromGoogleSheet = async () => {
    if (!googleToken || !connectedSheetInfo) return;
    if (!window.confirm(`Load content from Google Sheet "${connectedSheetInfo.title}" into the website? Any unsaved local edits will be replaced with data from the spreadsheet.`)) {
      return;
    }
    setSheetsLoading(true);
    setSheetsError(null);
    try {
      const loaded = await googleSheetsService.readContentFromSpreadsheet(googleToken, connectedSheetInfo.id, draftContent);
      setDraftContent(loaded);
      await onSaveContent(loaded);
      setStatusMessage('Website updated with content from Google Sheet!');
    } catch (err: any) {
      setSheetsError(err.message || 'Failed to read data from Google Sheet');
    } finally {
      setSheetsLoading(false);
    }
  };

  // Inquiries Actions
  const handleUpdateInquiryStatus = async (id: string, status: 'new' | 'contacted' | 'completed') => {
    try {
      await fetch(`/api/inquiries/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      setInquiries(inquiries.map(i => i.id === id ? { ...i, status } : i));
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteInquiry = async (id: string) => {
    if (!window.confirm('Delete this inquiry?')) return;
    try {
      await fetch(`/api/inquiries/${id}`, { method: 'DELETE' });
      setInquiries(inquiries.filter(i => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  // Project Management Actions
  const handleAddProject = () => {
    const newProj: Project = {
      id: `proj-${Date.now()}`,
      title: 'New Website Project',
      category: 'Business',
      shortDescription: 'Modern responsive website with clean layout and fast loading.',
      fullOverview: 'Detailed overview of this new website project showcasing custom architecture.',
      designHighlights: ['Modern clean typography', 'Responsive mobile-first layout', 'Dark studio theme'],
      features: ['Multi-page navigation', 'WhatsApp integration', 'Fast loading'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS'],
      imageUrl: '/src/assets/images/hero_web_mockup_1791840238520.jpg',
      liveUrl: 'https://wa.me/923440105980',
      featured: false
    };
    setDraftContent({
      ...draftContent,
      projects: [newProj, ...draftContent.projects]
    });
    setEditingProject(newProj);
  };

  const handleDeleteProject = (id: string) => {
    if (!window.confirm('Delete this project from the portfolio?')) return;
    setDraftContent({
      ...draftContent,
      projects: draftContent.projects.filter(p => p.id !== id)
    });
    if (editingProject?.id === id) setEditingProject(null);
  };

  const handleUpdateCurrentProject = (updated: Project) => {
    setDraftContent({
      ...draftContent,
      projects: draftContent.projects.map(p => p.id === updated.id ? updated : p)
    });
    setEditingProject(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-hidden animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[90vh] bg-[#090D15] border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* CMS Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#06090E]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Velo Web Content Management</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Backend Database
                </span>
                {connectedSheetInfo && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>Sheets Active</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Edit brand copy, portfolio projects, packages, and connect Google Sheets as a live backend.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] hover:from-[#38BDF8] hover:to-[#0284C7] rounded-lg shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors"
              aria-label="Close CMS"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Status Toast Banner */}
        {(saveSuccess || statusMessage) && (
          <div className="px-6 py-2.5 bg-emerald-950/80 border-b border-emerald-800/80 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMessage || 'Database updated successfully! All portfolio changes are live.'}</span>
            </div>
            {statusMessage && (
              <button onClick={() => setStatusMessage(null)} className="text-[11px] underline ml-2">
                Dismiss
              </button>
            )}
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 border-b border-slate-800/80 bg-[#080B12] overflow-x-auto">
          {[
            { id: 'brand', label: 'Brand & Socials', icon: <Settings className="w-3.5 h-3.5" /> },
            { id: 'projects', label: `Projects (${draftContent.projects.length})`, icon: <Layout className="w-3.5 h-3.5" /> },
            { id: 'packages', label: 'Packages & Scopes', icon: <PackageIcon className="w-3.5 h-3.5" /> },
            { id: 'inquiries', label: `Inquiries Leads (${inquiries.length})`, icon: <MessageSquare className="w-3.5 h-3.5" /> },
            { id: 'sheets', label: 'Google Sheets Backend', icon: <Table className="w-3.5 h-3.5 text-emerald-400" /> },
            { id: 'faqs', label: 'FAQs', icon: <HelpCircle className="w-3.5 h-3.5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.id === 'sheets' && connectedSheetInfo && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-0.5" />
              )}
            </button>
          ))}

          <div className="ml-auto">
            <button
              onClick={handleReset}
              className="text-[11px] text-slate-500 hover:text-rose-400 transition-colors inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Defaults</span>
            </button>
          </div>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#07090E]">
          {/* TAB: GOOGLE SHEETS BACKEND */}
          {activeTab === 'sheets' && (
            <div className="max-w-3xl space-y-6">
              <div className="p-5 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 font-semibold text-emerald-400 text-sm">
                  <Table className="w-4 h-4" />
                  <span>Google Sheets Data Backend</span>
                </div>
                <p className="leading-relaxed">
                  Use a Google Sheet as a live spreadsheet backend for Velo Web! Sync your brand content, portfolio projects, pricing packages, and have new client inquiries automatically appended to your sheet.
                </p>
              </div>

              {/* Error Callout */}
              {sheetsError && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs">
                  {sheetsError}
                </div>
              )}

              {/* 1. GOOGLE AUTHENTICATION SECTION */}
              <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Step 1: Google Account Access
                </div>

                {!googleUser ? (
                  <div className="space-y-3">
                    <p className="text-xs text-slate-300">
                      Sign in with Google to grant permission to create and manage spreadsheets in your Google Drive.
                    </p>

                    {/* Official Sign in with Google Button */}
                    <button
                      onClick={handleGoogleLogin}
                      disabled={sheetsLoading}
                      className="inline-flex items-center gap-3 px-5 py-2.5 rounded-lg bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold shadow-md transition-all cursor-pointer disabled:opacity-50"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 48 48">
                        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                      </svg>
                      <span>Sign in with Google</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="flex items-center gap-3">
                      {googleUser.photoURL ? (
                        <img src={googleUser.photoURL} alt="" className="w-8 h-8 rounded-full border border-slate-700" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-cyan-950 text-cyan-400 flex items-center justify-center font-bold text-xs">
                          {googleUser.displayName?.charAt(0) || 'G'}
                        </div>
                      )}
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-2">
                          <span>{googleUser.displayName || 'Google Account'}</span>
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full">
                            Connected
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {googleUser.email}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleGoogleSignOut}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-rose-300 bg-slate-900 border border-slate-800 rounded-lg transition-colors"
                    >
                      <LogOut className="w-3 h-3" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>

              {/* 2. SPREADSHEET BACKEND CONFIGURATION */}
              {googleUser && (
                <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-5">
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Step 2: Connect or Create Spreadsheet
                  </div>

                  {connectedSheetInfo ? (
                    <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="text-[11px] font-mono text-emerald-400 uppercase">Active Connected Backend</div>
                          <h4 className="text-base font-bold text-white flex items-center gap-2">
                            <span>{connectedSheetInfo.title}</span>
                          </h4>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5 truncate max-w-md">
                            ID: {connectedSheetInfo.id}
                          </div>
                        </div>

                        <a
                          href={connectedSheetInfo.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm whitespace-nowrap"
                        >
                          <span>Open in Google Sheets</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>

                      {/* Sheet Tabs Available */}
                      <div className="pt-3 border-t border-slate-800/80 flex flex-wrap gap-2 text-[11px] font-mono text-slate-300">
                        <span className="text-slate-500">Tabs:</span>
                        {connectedSheetInfo.sheets.map((sheet, i) => (
                          <span key={i} className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-cyan-300">
                            {sheet}
                          </span>
                        ))}
                      </div>

                      {/* Two-Way Synchronization Controls */}
                      <div className="pt-4 border-t border-slate-800 flex flex-wrap gap-3">
                        <button
                          onClick={handlePushToGoogleSheet}
                          disabled={sheetsLoading}
                          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-all"
                        >
                          <ArrowUpFromLine className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Push Current Website Data to Sheet</span>
                        </button>

                        <button
                          onClick={handlePullFromGoogleSheet}
                          disabled={sheetsLoading}
                          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/60 rounded-lg transition-all"
                        >
                          <ArrowDownToLine className="w-3.5 h-3.5" />
                          <span>Pull Data from Google Sheet to Website</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Option A: 1-Click Create */}
                      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                        <div className="text-xs font-bold text-white">
                          Option A: 1-Click Create New Database Sheet
                        </div>
                        <p className="text-xs text-slate-400">
                          Automatically creates a spreadsheet in your Google Drive with formatted tabs for <strong>Brand & Config</strong>, <strong>Projects</strong>, <strong>Packages</strong>, and <strong>Client Inquiries</strong>, pre-filled with current data.
                        </p>
                        <button
                          onClick={handleCreateNewSheet}
                          disabled={sheetsLoading}
                          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 rounded-lg shadow-sm"
                        >
                          <Plus className="w-4 h-4" />
                          <span>{sheetsLoading ? 'Creating Sheet...' : 'Create New Velo Web Sheet in Google Drive'}</span>
                        </button>
                      </div>

                      {/* Option B: Connect Existing */}
                      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                        <div className="text-xs font-bold text-white">
                          Option B: Connect Existing Google Sheet
                        </div>
                        <p className="text-xs text-slate-400">
                          Paste the full URL or Spreadsheet ID of a Google Sheet you own or have edit access to.
                        </p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="https://docs.google.com/spreadsheets/d/1BxiMVs0XR.../edit or Spreadsheet ID"
                            value={customSheetInput}
                            onChange={(e) => setCustomSheetInput(e.target.value)}
                            className="flex-1 px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-800 text-white font-mono placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                          />
                          <button
                            onClick={handleConnectExistingSheet}
                            disabled={sheetsLoading}
                            className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg whitespace-nowrap"
                          >
                            <span>Connect</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 1: BRAND & SOCIALS */}
          {activeTab === 'brand' && (
            <div className="max-w-3xl space-y-6">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400">
                Update brand details, WhatsApp connection link, social handles, and transparent domain policy copy.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Brand Name</label>
                  <input
                    type="text"
                    value={draftContent.brand.name}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, name: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Positioning Headline</label>
                  <input
                    type="text"
                    value={draftContent.brand.positioning}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, positioning: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">WhatsApp Phone Number</label>
                  <input
                    type="text"
                    value={draftContent.brand.whatsappNumber}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, whatsappNumber: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">WhatsApp Direct URL</label>
                  <input
                    type="text"
                    value={draftContent.brand.whatsappLink}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, whatsappLink: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Instagram Handle</label>
                  <input
                    type="text"
                    value={draftContent.brand.instagramHandle}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, instagramHandle: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Instagram URL</label>
                  <input
                    type="text"
                    value={draftContent.brand.instagramUrl}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, instagramUrl: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Facebook Page Name</label>
                  <input
                    type="text"
                    value={draftContent.brand.facebookName}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, facebookName: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Facebook URL</label>
                  <input
                    type="text"
                    value={draftContent.brand.facebookUrl}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, facebookUrl: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="text-xs font-bold text-slate-200">Domain Add-on Policies</div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Short Domain Policy</label>
                  <input
                    type="text"
                    value={draftContent.brand.domainPolicyShort}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, domainPolicyShort: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Full Domain Policy Explanation</label>
                  <textarea
                    rows={3}
                    value={draftContent.brand.domainPolicyFull}
                    onChange={(e) => setDraftContent({
                      ...draftContent,
                      brand: { ...draftContent.brand, domainPolicyFull: e.target.value }
                    })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:border-cyan-500 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PROJECTS */}
          {activeTab === 'projects' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">Portfolio Projects</h4>
                  <p className="text-xs text-slate-400">Add, edit, or customize website portfolio cards.</p>
                </div>
                <button
                  onClick={handleAddProject}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 rounded-lg hover:bg-cyan-500/30"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Project</span>
                </button>
              </div>

              {/* Editing Project Sub-form */}
              {editingProject && (
                <div className="p-5 rounded-xl bg-slate-900/90 border border-cyan-500/40 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <span className="text-xs font-bold text-cyan-300">
                      Editing: {editingProject.title}
                    </span>
                    <button
                      onClick={() => setEditingProject(null)}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Done editing this project
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Project Title</label>
                      <input
                        type="text"
                        value={editingProject.title}
                        onChange={(e) => handleUpdateCurrentProject({ ...editingProject, title: e.target.value })}
                        className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Category</label>
                      <select
                        value={editingProject.category}
                        onChange={(e) => handleUpdateCurrentProject({ ...editingProject, category: e.target.value as any })}
                        className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white"
                      >
                        {['Business', 'Landing Page', 'Portfolio', 'E-commerce', 'Company', 'Custom'].map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Image URL / Path</label>
                    <input
                      type="text"
                      value={editingProject.imageUrl}
                      onChange={(e) => handleUpdateCurrentProject({ ...editingProject, imageUrl: e.target.value })}
                      className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Short Description</label>
                    <input
                      type="text"
                      value={editingProject.shortDescription}
                      onChange={(e) => handleUpdateCurrentProject({ ...editingProject, shortDescription: e.target.value })}
                      className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Full Overview</label>
                    <textarea
                      rows={2}
                      value={editingProject.fullOverview}
                      onChange={(e) => handleUpdateCurrentProject({ ...editingProject, fullOverview: e.target.value })}
                      className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Technologies (comma-separated)</label>
                    <input
                      type="text"
                      value={editingProject.technologies.join(', ')}
                      onChange={(e) => handleUpdateCurrentProject({
                        ...editingProject,
                        technologies: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      })}
                      className="w-full px-3 py-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Projects List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {draftContent.projects.map((proj) => (
                  <div
                    key={proj.id}
                    className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-4 justify-between"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={proj.imageUrl}
                        alt=""
                        className="w-16 h-12 object-cover rounded border border-slate-800 shrink-0 bg-slate-950"
                      />
                      <div>
                        <div className="text-xs font-mono text-cyan-400">{proj.category}</div>
                        <div className="text-sm font-bold text-white">{proj.title}</div>
                        <div className="text-xs text-slate-400 line-clamp-1">{proj.shortDescription}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => setEditingProject(proj)}
                        className="p-1.5 text-slate-400 hover:text-cyan-300 bg-slate-800 rounded"
                        title="Edit Project"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteProject(proj.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-800 rounded"
                        title="Delete Project"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PACKAGES */}
          {activeTab === 'packages' && (
            <div className="space-y-6 max-w-3xl">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400">
                Customize package descriptions and notes. All packages link directly to WhatsApp for quotes.
              </div>

              {draftContent.packages.map((pkg, idx) => (
                <div key={pkg.id} className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-cyan-400">Package #{idx + 1}</span>
                    <input
                      type="text"
                      value={pkg.badge || ''}
                      onChange={(e) => {
                        const updated = [...draftContent.packages];
                        updated[idx].badge = e.target.value;
                        setDraftContent({ ...draftContent, packages: updated });
                      }}
                      placeholder="Badge (e.g. Most Popular)"
                      className="px-2 py-1 text-[11px] rounded bg-slate-950 border border-slate-800 text-slate-300"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Package Name</label>
                      <input
                        type="text"
                        value={pkg.name}
                        onChange={(e) => {
                          const updated = [...draftContent.packages];
                          updated[idx].name = e.target.value;
                          setDraftContent({ ...draftContent, packages: updated });
                        }}
                        className="w-full px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-800 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Pricing Note</label>
                      <input
                        type="text"
                        value={pkg.pricingNote}
                        onChange={(e) => {
                          const updated = [...draftContent.packages];
                          updated[idx].pricingNote = e.target.value;
                          setDraftContent({ ...draftContent, packages: updated });
                        }}
                        className="w-full px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-800 text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Description</label>
                    <input
                      type="text"
                      value={pkg.description}
                      onChange={(e) => {
                        const updated = [...draftContent.packages];
                        updated[idx].description = e.target.value;
                        setDraftContent({ ...draftContent, packages: updated });
                      }}
                      className="w-full px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-800 text-white"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: INQUIRIES LEADS */}
          {activeTab === 'inquiries' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">Client Inquiry Leads</h4>
                  <p className="text-xs text-slate-400">
                    Inquiries submitted via the on-site form are saved to the backend database {connectedSheetInfo ? 'and synced to Google Sheets!' : '.'}
                  </p>
                </div>
                <button
                  onClick={fetchInquiries}
                  className="px-3 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded"
                >
                  Refresh Leads
                </button>
              </div>

              {inquiriesLoading ? (
                <div className="py-12 text-center text-xs text-slate-500">Loading inquiries...</div>
              ) : inquiries.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500">No client inquiries logged yet.</div>
              ) : (
                <div className="space-y-3">
                  {inquiries.map((inq) => (
                    <div
                      key={inq.id}
                      className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{inq.name}</span>
                          <span className="text-xs font-mono text-cyan-400">({inq.contactMethod})</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-mono ${
                            inq.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                            inq.status === 'contacted' ? 'bg-sky-950 text-sky-400 border border-sky-800' :
                            'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}>
                            {inq.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-300">
                          <span className="font-semibold text-slate-400">Type: </span>{inq.projectType}
                        </div>
                        <p className="text-xs text-slate-400 max-w-xl">
                          "{inq.projectDetails}"
                        </p>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {new Date(inq.createdAt).toLocaleString()}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* Status toggles */}
                        <select
                          value={inq.status}
                          onChange={(e) => handleUpdateInquiryStatus(inq.id, e.target.value as any)}
                          className="px-2 py-1 text-xs bg-slate-950 border border-slate-800 rounded text-slate-300"
                        >
                          <option value="new">New</option>
                          <option value="contacted">Contacted</option>
                          <option value="completed">Completed</option>
                        </select>

                        <a
                          href={`https://wa.me/?text=${encodeURIComponent(`Hi ${inq.name}, Velo Web here following up on your ${inq.projectType} inquiry.`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 text-emerald-400 hover:text-emerald-300 bg-slate-800 rounded"
                          title="Message Client on WhatsApp"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </a>

                        <button
                          onClick={() => handleDeleteInquiry(inq.id)}
                          className="p-1.5 text-rose-400 hover:text-rose-300 bg-slate-800 rounded"
                          title="Delete Inquiry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: FAQS */}
          {activeTab === 'faqs' && (
            <div className="space-y-6 max-w-3xl">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400">
                Manage FAQ items. The clear NO to SEO and transparent domain pricing answers are preserved by default.
              </div>

              {draftContent.faqs.map((faq, idx) => (
                <div key={faq.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs text-cyan-400 font-mono">
                    <span>Question {idx + 1}</span>
                  </div>
                  <input
                    type="text"
                    value={faq.question}
                    onChange={(e) => {
                      const updated = [...draftContent.faqs];
                      updated[idx].question = e.target.value;
                      setDraftContent({ ...draftContent, faqs: updated });
                    }}
                    className="w-full px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-800 text-white font-semibold"
                  />
                  <textarea
                    rows={2}
                    value={faq.answer}
                    onChange={(e) => {
                      const updated = [...draftContent.faqs];
                      updated[idx].answer = e.target.value;
                      setDraftContent({ ...draftContent, faqs: updated });
                    }}
                    className="w-full px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-800 text-slate-300 resize-none"
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
