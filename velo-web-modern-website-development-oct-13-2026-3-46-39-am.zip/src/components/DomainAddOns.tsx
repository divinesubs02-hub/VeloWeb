import React from 'react';
import { Globe, Link2, Info, ArrowUpRight } from 'lucide-react';
import { AddOn, BrandConfig } from '../types';

interface DomainAddOnsProps {
  addOns: AddOn[];
  brand: BrandConfig;
}

export const DomainAddOns: React.FC<DomainAddOnsProps> = ({ addOns, brand }) => {
  return (
    <section className="py-20 relative bg-[#090D15] border-t border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Block */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-2">
            <Info className="w-3.5 h-3.5" />
            <span>Optional Enhancements</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Optional Website Add-Ons
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
            {brand.domainPolicyFull}
          </p>
        </div>

        {/* Transparent Policy Notice Banner */}
        <div className="mb-10 p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 flex items-start gap-3">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-white">Transparent Policy: </span>
            {brand.domainPolicyShort} Domain purchasing and domain connection/setup are NOT included in the standard website development price. They are optional additional services and are charged separately based on your registrar and domain extension requirements.
          </div>
        </div>

        {/* 2 Clear Add-on Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {addOns.map((addon) => {
            const isPurchase = addon.id.includes('purchase');
            const encoded = encodeURIComponent(
              `Hi Velo Web, I would like to inquire about ${addon.title}`
            );
            const whatsappUrl = `${brand.whatsappLink}?text=${encoded}`;

            return (
              <div
                key={addon.id}
                className="rounded-2xl bg-[#0B0F17] border border-slate-800/90 p-7 flex flex-col justify-between hover:border-cyan-500/30 transition-all duration-200"
              >
                <div>
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                      {isPurchase ? (
                        <Globe className="w-5 h-5 text-cyan-400" />
                      ) : (
                        <Link2 className="w-5 h-5 text-cyan-400" />
                      )}
                    </div>
                    {/* Clear Separate Charge Pill Badge */}
                    <span className="text-[11px] font-medium text-amber-300/90 bg-amber-950/40 border border-amber-800/50 px-2.5 py-1 rounded-full">
                      {addon.chargeNotice}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2">
                    {addon.title}
                  </h3>
                  <p className="text-sm font-medium text-cyan-300/90 mb-3">
                    "{addon.description}"
                  </p>
                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {addon.details}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-xs text-slate-400">
                    Billed separately from website dev
                  </span>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <span>Ask on WhatsApp</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
