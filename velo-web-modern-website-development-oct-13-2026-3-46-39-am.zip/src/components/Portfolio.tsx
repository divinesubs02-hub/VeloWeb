import React, { useState } from 'react';
import { Eye, ExternalLink, ArrowUpRight, Sparkles } from 'lucide-react';
import { Project, BrandConfig } from '../types';
import { ProjectDetailModal } from './ProjectDetailModal';

interface PortfolioProps {
  projects: Project[];
  brand: BrandConfig;
  onOpenCMS: () => void;
}

export const Portfolio: React.FC<PortfolioProps> = ({ projects, brand, onOpenCMS }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeModalProject, setActiveModalProject] = useState<Project | null>(null);

  const categories = ['All', 'Business', 'Landing Page', 'Portfolio', 'E-commerce', 'Company'];

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter(p => p.category === selectedCategory);

  return (
    <section id="work" className="py-24 relative bg-[#07090E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
              Portfolio
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
              Selected Work
            </h2>
            <p className="mt-3 text-base text-slate-400 max-w-xl">
              Explore websites and digital experiences created by Velo Web. Clean design, fast loading, and responsive across every device.
            </p>
          </div>

          {/* Interactive Category Filter Tabs (Single-line functional buttons) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 border border-slate-800 rounded-xl">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-slate-800 text-white shadow-xs border border-slate-700/80 text-cyan-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group rounded-2xl bg-[#0B0F17] border border-slate-800/90 overflow-hidden flex flex-col justify-between hover:border-cyan-500/40 hover:shadow-xl hover:shadow-cyan-950/20 transition-all duration-300"
            >
              <div>
                {/* Mockup Image Container */}
                <div className="relative aspect-[4/3] bg-slate-950 overflow-hidden border-b border-slate-800/80">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />

                  {/* Overlay Action Buttons on Hover */}
                  <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-3 p-4">
                    <button
                      onClick={() => setActiveModalProject(project)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-[#00E5FF] hover:bg-[#38BDF8] rounded-lg shadow-md transition-all cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Details</span>
                    </button>
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Inquire</span>
                    </a>
                  </div>
                </div>

                {/* Card Content Details */}
                <div className="p-6">
                  {/* Category and Tech inline metadata (Zero-pill discipline) */}
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                    <span className="font-semibold text-cyan-400">{project.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>Responsive Website</span>
                  </div>

                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors mb-2">
                    {project.title}
                  </h3>

                  <p className="text-sm text-slate-400 leading-relaxed line-clamp-2 mb-4">
                    {project.shortDescription}
                  </p>

                  {/* Stack Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-800/80">
                    {project.technologies.slice(0, 3).map((tech, i) => (
                      <span
                        key={i}
                        className="text-[11px] font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-900/80 border border-slate-800"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                      <span className="text-[11px] font-mono text-slate-500 px-1 py-0.5">
                        +{project.technologies.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-6 py-4 border-t border-slate-800/80 bg-[#090D14] flex items-center justify-between">
                <button
                  onClick={() => setActiveModalProject(project)}
                  className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors inline-flex items-center gap-1"
                >
                  <span>View Project</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>

                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-slate-400 hover:text-white transition-colors"
                >
                  Live Website
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Dynamic CMS Note Footer */}
        <div className="mt-12 p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-center flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              All projects are fully editable. You can replace images, add real client links, or introduce new website categories.
            </span>
          </div>
          <button
            onClick={onOpenCMS}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 underline underline-offset-4 shrink-0"
          >
            Manage Portfolio in CMS →
          </button>
        </div>
      </div>

      {/* Interactive Detail Modal */}
      <ProjectDetailModal
        project={activeModalProject}
        brand={brand}
        onClose={() => setActiveModalProject(null)}
      />
    </section>
  );
};
