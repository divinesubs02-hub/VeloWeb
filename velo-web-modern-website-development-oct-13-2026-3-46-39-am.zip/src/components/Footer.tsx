import React from 'react';
import { MessageCircle, Instagram, Facebook, ArrowUpRight, SlidersHorizontal } from 'lucide-react';
import { VeloLogo } from './VeloLogo';
import { BrandConfig } from '../types';

interface FooterProps {
  brand: BrandConfig;
  onOpenCMS: () => void;
}

export const Footer: React.FC<FooterProps> = ({ brand, onOpenCMS }) => {
  const navLinks = [
    { label: 'Home', href: '#' },
    { label: 'Services', href: '#services' },
    { label: 'Work', href: '#work' },
    { label: 'Process', href: '#process' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer className="bg-[#05070B] border-t border-slate-900 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-900">
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <VeloLogo size="lg" withWordmark={true} withTagline={true} />
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed pt-2">
              Modern website development studio. Turning ideas into professional, responsive, and high-performance digital experiences.
            </p>
            <div className="text-xs text-slate-400">
              WhatsApp: <span className="text-slate-300 font-mono">{brand.whatsappNumber}</span>
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Navigation
            </div>
            <ul className="grid grid-cols-2 gap-2 text-xs">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-cyan-400 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social Links */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Connect With Us
            </div>
            <div className="flex flex-col space-y-2.5 text-xs">
              <a
                href={brand.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 hover:text-cyan-400 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp</span>
                <ArrowUpRight className="w-3 h-3 text-slate-600" />
              </a>

              <a
                href={brand.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 hover:text-cyan-400 transition-colors"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span>Instagram ({brand.instagramHandle})</span>
                <ArrowUpRight className="w-3 h-3 text-slate-600" />
              </a>

              <a
                href={brand.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 hover:text-cyan-400 transition-colors"
              >
                <Facebook className="w-4 h-4 text-blue-400" />
                <span>Facebook ({brand.facebookName})</span>
                <ArrowUpRight className="w-3 h-3 text-slate-600" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © 2026 Velo Web. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <span className="text-[11px] text-slate-400">
              Modern Website Development
            </span>
            <span className="text-slate-700">·</span>
            <button
              onClick={onOpenCMS}
              className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-cyan-300 transition-colors"
            >
              <SlidersHorizontal className="w-3 h-3 text-cyan-400" />
              <span>Database CMS</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
