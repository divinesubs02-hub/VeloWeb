import React, { useState } from 'react';
import { ArrowUpRight, ArrowDown, Monitor, Smartphone, Check, Sparkles, Wifi, Battery } from 'lucide-react';
import { BrandConfig } from '../types';

interface HeroProps {
  brand: BrandConfig;
}

export const Hero: React.FC<HeroProps> = ({ brand }) => {
  const [activePreviewMode, setActivePreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  return (
    <section className="relative pt-28 pb-16 sm:pt-32 sm:pb-20 md:pt-36 md:pb-24 lg:pt-40 lg:pb-28 overflow-hidden">
      {/* Subtle Background Glow Mesh */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] md:w-[700px] h-[400px] bg-gradient-to-tr from-cyan-500/10 via-sky-600/5 to-transparent blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute top-20 right-10 w-72 md:w-96 h-72 md:h-96 bg-cyan-600/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-12 lg:gap-8 items-center">
          {/* Left Column: Headlines & Positioning */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-5 md:space-y-6 max-w-2xl lg:max-w-none mx-auto lg:mx-0">
            {/* Availability & Positioning Header (Clean unboxed inline metadata) */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs text-slate-300">
              <span className="font-semibold text-cyan-400">{brand.positioning}</span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span className="text-slate-300 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {brand.availability}
              </span>
            </div>

            {/* Main Headline (Tablet-tuned responsive type scale) */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] xl:text-[3.75rem] font-extrabold text-white tracking-tight leading-[1.14] text-balance">
              We Build Websites That Make Your Business{' '}
              <span className="bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
                Look Professional.
              </span>
            </h1>

            {/* Supporting Headline & Paragraph */}
            <p className="text-base sm:text-lg md:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl">
              From simple landing pages to complete business websites, Velo Web turns your ideas into modern, responsive websites.
            </p>

            <p className="text-xs sm:text-sm md:text-base text-slate-400 leading-relaxed max-w-2xl">
              Velo Web creates modern websites for businesses, startups, creators, and individuals who want a professional online presence without unnecessary complexity.
            </p>

            {/* Primary & Secondary Action CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 sm:gap-4 pt-1 sm:pt-2 w-full sm:w-auto">
              <a
                href="#work"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/50 rounded-xl transition-all duration-200 shadow-sm"
              >
                <span>View Our Work</span>
                <ArrowDown className="w-4 h-4 text-cyan-400" />
              </a>

              <a
                href={brand.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 text-xs sm:text-sm font-semibold text-slate-950 bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] hover:from-[#38BDF8] hover:to-[#0284C7] rounded-xl shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all duration-200"
              >
                <span>Start a Project</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* Direct Value Pillars (Unboxed clean inline list) */}
            <div className="pt-5 border-t border-slate-800/80 w-full grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>100% Responsive Design</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Modern Clean Architecture</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Direct WhatsApp Comms</span>
              </div>
            </div>
          </div>

          {/* Right Column: High-Impact Visual Showcase with Authentic Desktop & Mobile Viewports */}
          <div className="lg:col-span-5 relative w-full max-w-xl lg:max-w-none mx-auto">
            {/* Device Viewport Toggle (Interactive tab control) */}
            <div className="flex items-center justify-between mb-3 px-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-medium text-slate-300">Live Website Preview Mockup</span>
              </div>
              <div className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-lg shadow-sm">
                <button
                  onClick={() => setActivePreviewMode('desktop')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-all ${
                    activePreviewMode === 'desktop'
                      ? 'bg-slate-800 text-cyan-300 border border-slate-700/80 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  aria-label="Desktop Preview View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Desktop</span>
                </button>
                <button
                  onClick={() => setActivePreviewMode('mobile')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-all ${
                    activePreviewMode === 'mobile'
                      ? 'bg-slate-800 text-cyan-300 border border-slate-700/80 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  aria-label="Mobile Preview View"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Mobile</span>
                </button>
              </div>
            </div>

            {/* PREVIEW CONTAINER */}
            <div className="relative flex items-center justify-center min-h-[380px] sm:min-h-[440px] md:min-h-[460px]">
              {/* DESKTOP VIEW MOCKUP */}
              {activePreviewMode === 'desktop' ? (
                <div className="w-full rounded-2xl border border-slate-800/90 bg-[#0B0F17] shadow-2xl shadow-cyan-950/30 overflow-hidden group transition-all duration-300 animate-in fade-in zoom-in-95">
                  {/* Browser Window Header Chrome */}
                  <div className="flex items-center justify-between px-4 py-3 bg-[#080D15] border-b border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                      <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                      <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                    </div>
                    <div className="px-3.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] text-slate-400 font-mono flex items-center gap-2 max-w-[220px] sm:max-w-none truncate">
                      <span className="text-cyan-400">https://</span>
                      <span className="truncate">veloweb.dev/portfolio</span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono hidden sm:block">1440 × 900</div>
                  </div>

                  {/* Showcase Desktop Image */}
                  <div className="relative aspect-[16/10] bg-slate-950 overflow-hidden">
                    <img
                      src="/src/assets/images/hero_web_mockup_1791840238520.jpg"
                      alt="Velo Web responsive modern website mockups showcase"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-102"
                    />

                    {/* Subtle Inner Gradient Shade */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17]/90 via-transparent to-transparent opacity-60 pointer-events-none" />

                    {/* Floating Micro-Badge */}
                    <div className="absolute bottom-3 left-3 right-3 sm:bottom-4 sm:left-4 sm:right-4 flex items-center justify-between text-xs backdrop-blur-md bg-slate-950/85 border border-slate-800/90 p-2.5 sm:p-3 rounded-xl">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-cyan-400" />
                        <span className="text-slate-200 font-medium text-[11px] sm:text-xs">Desktop Viewport · Full Width</span>
                      </div>
                      <span className="text-slate-400 font-mono text-[10px] sm:text-[11px]">Clean · Fast · Modern</span>
                    </div>
                  </div>
                </div>
              ) : (
                /* AUTHENTIC MOBILE SMARTPHONE VIEW MOCKUP */
                <div className="w-full max-w-[290px] sm:max-w-[310px] mx-auto rounded-[40px] p-2.5 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 border-2 border-slate-700 shadow-2xl shadow-cyan-950/40 relative overflow-hidden transition-all duration-300 animate-in fade-in zoom-in-95">
                  {/* Smartphone Inner Screen Bezel */}
                  <div className="relative rounded-[32px] bg-[#070A10] overflow-hidden border border-slate-800">
                    {/* Top Status Bar & Dynamic Island */}
                    <div className="px-5 pt-3 pb-2 flex items-center justify-between bg-black/80 text-[10px] text-slate-300 font-medium select-none">
                      <span>9:41</span>
                      {/* Dynamic Island Pill */}
                      <div className="w-20 h-4 bg-black rounded-full flex items-center justify-center border border-slate-800">
                        <div className="w-2 h-2 rounded-full bg-slate-900 ml-auto mr-1.5" />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Wifi className="w-3 h-3 text-slate-400" />
                        <Battery className="w-3.5 h-3.5 text-slate-300" />
                      </div>
                    </div>

                    {/* Mobile Browser Address Bar */}
                    <div className="px-3 py-1.5 bg-[#0D121D] border-b border-slate-800 flex items-center justify-between text-[11px]">
                      <div className="w-full py-1 px-3 rounded-lg bg-slate-900/90 border border-slate-800/80 text-slate-300 font-mono text-center flex items-center justify-center gap-1.5">
                        <span className="text-cyan-400 text-[10px]">🔒</span>
                        <span className="text-xs">veloweb.dev</span>
                      </div>
                    </div>

                    {/* Authentic Mobile Website Screenshot */}
                    <div className="relative aspect-[9/16] bg-slate-950 overflow-hidden">
                      <img
                        src="/src/assets/images/mockup_mobile_view_1791842405241.jpg"
                        alt="Velo Web responsive mobile website mockup"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-top"
                      />

                      {/* Floating Mobile Badge */}
                      <div className="absolute bottom-3 left-3 right-3 p-2 rounded-xl backdrop-blur-md bg-slate-950/90 border border-slate-800 text-[11px] flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-cyan-300 font-semibold">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                          <span>Mobile View (390px)</span>
                        </div>
                        <span className="text-slate-400 text-[10px]">100% Touch-Ready</span>
                      </div>
                    </div>

                    {/* Bottom Home Indicator Bar */}
                    <div className="py-2 bg-black flex items-center justify-center">
                      <div className="w-28 h-1 bg-slate-600 rounded-full" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Floating Subtle Value Pill (Contained without overflowing) */}
            <div className="hidden lg:flex items-center gap-3 absolute -bottom-5 right-2 p-3 rounded-xl bg-slate-900/95 border border-slate-800 shadow-xl backdrop-blur-md text-xs">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
              <span className="text-slate-300 font-medium">
                "You have an idea. Velo Web turns it into a website."
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
