import React from 'react';

interface VeloLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  withWordmark?: boolean;
  withTagline?: boolean;
  className?: string;
}

export const VeloLogo: React.FC<VeloLogoProps> = ({
  size = 'md',
  withWordmark = true,
  withTagline = false,
  className = '',
}) => {
  // Dimension definitions
  const dimensions = {
    sm: { icon: 30, text: 'text-base', subtext: 'text-[9px]' },
    md: { icon: 38, text: 'text-lg', subtext: 'text-[10px]' },
    lg: { icon: 52, text: 'text-xl', subtext: 'text-xs' },
    xl: { icon: 72, text: 'text-2xl', subtext: 'text-sm' },
    hero: { icon: 110, text: 'text-4xl', subtext: 'text-base' }
  }[size];

  const iconPx = dimensions.icon;

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* High-tech circular emblem SVG matching the uploaded brand asset */}
      <div 
        className="relative shrink-0 flex items-center justify-center rounded-full p-[2px] transition-transform duration-300 hover:scale-105"
        style={{
          width: iconPx,
          height: iconPx,
          background: 'radial-gradient(circle at 50% 50%, #0F1D33 0%, #070B12 100%)',
          boxShadow: '0 0 16px -2px rgba(0, 210, 255, 0.4), inset 0 0 12px 1px rgba(0, 210, 255, 0.2)'
        }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Outer Cyan Ring Gradient */}
            <linearGradient id="veloBorderGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="50%" stopColor="#0284C7" />
              <stop offset="100%" stopColor="#00E5FF" />
            </linearGradient>

            {/* V Letter Gradient */}
            <linearGradient id="veloVGrad" x1="20%" y1="0%" x2="80%" y2="100%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="45%" stopColor="#0088FF" />
              <stop offset="100%" stopColor="#0284C7" />
            </linearGradient>

            {/* V Right Arm White/Silver Gradient */}
            <linearGradient id="veloRightArmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="85%" stopColor="#E2E8F0" />
              <stop offset="100%" stopColor="#94A3B8" />
            </linearGradient>

            {/* Orbital Ring Glow Gradient */}
            <linearGradient id="veloOrbitGrad" x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="50%" stopColor="#38BDF8" />
              <stop offset="100%" stopColor="#0284C7" />
            </linearGradient>

            {/* Glow Filter */}
            <filter id="veloGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Glowing Outer Circular Track */}
          <circle
            cx="50"
            cy="50"
            r="46"
            stroke="url(#veloBorderGrad)"
            strokeWidth="3"
            filter="url(#veloGlow)"
            strokeOpacity="0.9"
          />
          <circle
            cx="50"
            cy="50"
            r="46"
            stroke="#00E5FF"
            strokeWidth="1.2"
          />

          {/* Background Dark Emblem Fill */}
          <circle
            cx="50"
            cy="50"
            r="44"
            fill="#080D17"
          />

          {/* Lower Section of Orbital Ring (behind right wing) */}
          <path
            d="M 22 56 C 26 68 56 66 74 46"
            stroke="url(#veloOrbitGrad)"
            strokeWidth="3.2"
            strokeLinecap="round"
            opacity="0.75"
          />

          {/* Stylized Modern 'V' Mark */}
          {/* Left Wing (Bold Cyan) */}
          <path
            d="M 28 27 L 46 68 L 54 68 L 40 27 Z"
            fill="url(#veloVGrad)"
          />

          {/* Right Wing (Sharp Modern White/Silver with dynamic slant) */}
          <path
            d="M 43 65 L 70 31 L 61 31 L 38 65 Z"
            fill="url(#veloRightArmGrad)"
          />

          {/* Forefront Orbital Swoosh (cutting dynamically across the V) */}
          <path
            d="M 28 61 C 24 50 36 38 68 32 C 78 30 75 35 70 41 C 58 52 35 59 28 61 Z"
            fill="url(#veloOrbitGrad)"
            opacity="0.95"
            filter="url(#veloGlow)"
          />
          <path
            d="M 30 60 C 26 49 38 39 67 33"
            stroke="#FFFFFF"
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.9"
          />
        </svg>
      </div>

      {/* Typography Lockup */}
      {withWordmark && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center tracking-tight">
            <span className={`font-extrabold text-white ${dimensions.text}`}>
              Velo
            </span>
            <span className={`font-extrabold bg-gradient-to-r from-[#00D2FF] to-[#0284C7] bg-clip-text text-transparent ${dimensions.text}`}>
              Web
            </span>
          </div>
          {withTagline && (
            <span className={`text-slate-400 font-medium tracking-wide mt-0.5 ${dimensions.subtext}`}>
              Modern Websites. Real Results.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
