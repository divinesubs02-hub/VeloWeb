import React from 'react';
import { Check, ArrowUpRight, MessageCircle, AlertCircle } from 'lucide-react';
import { Package, BrandConfig } from '../types';

interface PackagesProps {
  packages: Package[];
  brand: BrandConfig;
}

export const Packages: React.FC<PackagesProps> = ({ packages, brand }) => {
  return (
    <section id="packages" className="py-24 relative bg-[#090D15] border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
            Investment & Scopes
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Website Packages
          </h2>
          <p className="mt-3 text-base text-slate-400">
            Tailored website packages built around your business requirements. Contact Velo Web for a custom quote based on your specific scope.
          </p>
        </div>

        {/* 3 Packages Cards (Tablet-optimized layout) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-4 lg:gap-8">
          {packages.map((pkg, idx) => {
            const isPopular = pkg.id === 'pkg-business';
            const encoded = encodeURIComponent(
              `Hi Velo Web, I would like to get a custom quote for the ${pkg.name}.`
            );
            const whatsappUrl = `${brand.whatsappLink}?text=${encoded}`;

            return (
              <div
                key={pkg.id}
                className={`relative rounded-2xl bg-[#0B0F17] border p-6 md:p-5 lg:p-8 flex flex-col justify-between transition-all duration-300 ${
                  isPopular
                    ? 'border-cyan-500/60 shadow-xl shadow-cyan-950/20 ring-1 ring-cyan-500/20'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  {/* Badge */}
                  {pkg.badge && (
                    <div className="mb-4">
                      <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${
                        isPopular
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {pkg.badge}
                      </span>
                    </div>
                  )}

                  <h3 className="text-xl font-bold text-white mb-2">
                    {pkg.name}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {pkg.description}
                  </p>

                  {/* Pricing Callout */}
                  <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/90 mb-6">
                    <div className="text-[11px] uppercase tracking-wider text-slate-500 font-mono mb-1">
                      Pricing
                    </div>
                    <div className="text-sm font-semibold text-cyan-300">
                      {pkg.pricingNote}
                    </div>
                  </div>

                  {/* Highlights List */}
                  <div className="space-y-3 mb-8">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Included In Package
                    </div>
                    {pkg.highlights.map((item, hIdx) => (
                      <div key={hIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer Action */}
                <div className="pt-6 border-t border-slate-800/80">
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold rounded-xl transition-all ${
                      isPopular
                        ? 'bg-gradient-to-r from-[#00E5FF] to-[#38BDF8] text-slate-950 hover:shadow-lg hover:shadow-cyan-500/25'
                        : 'bg-slate-900 hover:bg-slate-800 text-white border border-slate-700'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Get Custom Quote on WhatsApp</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Clear Domain Policy Disclaimer in Pricing */}
        <div className="mt-12 p-4 rounded-xl bg-[#080D15] border border-slate-800/80 flex items-start gap-3 max-w-3xl mx-auto text-xs text-slate-400">
          <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-white">Domain Policy Reminder: </span>
            Domain purchase, domain connection, and setup are optional and charged separately. They are not bundled into the base website development price.
          </div>
        </div>
      </div>
    </section>
  );
};
