import React from 'react';
import { Palette, Smartphone, Cpu, MessageCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { VeloLogo } from './VeloLogo';
import { BrandConfig } from '../types';

interface AboutProps {
  brand: BrandConfig;
}

export const About: React.FC<AboutProps> = ({ brand }) => {
  const whyCards = [
    {
      title: 'Modern Design',
      description: 'Clean and professional websites designed to make a strong first impression.',
      icon: <Palette className="w-5 h-5 text-cyan-400" />,
      detail: 'Tailored aesthetics with high readability, refined typography, and purposeful layouts.'
    },
    {
      title: 'Responsive',
      description: 'Websites designed to work smoothly across phones, tablets, and desktops.',
      icon: <Smartphone className="w-5 h-5 text-cyan-400" />,
      detail: 'Meticulously tested viewport scaling that looks stunning on every modern screen size.'
    },
    {
      title: 'AI-Assisted Development',
      description: 'Modern AI-powered tools help speed up the development process.',
      icon: <Cpu className="w-5 h-5 text-cyan-400" />,
      detail: 'Leveraging cutting-edge tools to accelerate build cycles without compromising code quality.'
    },
    {
      title: 'Direct Communication',
      description: 'Easy communication directly through WhatsApp.',
      icon: <MessageCircle className="w-5 h-5 text-cyan-400" />,
      detail: 'No ticketing queues or layers of middlemen. Direct, responsive updates on your website.'
    }
  ];

  const highlights = [
    'Modern design',
    'Responsive websites',
    'AI-assisted development',
    'Fast development workflow',
    'Client-focused process',
    'Custom website solutions'
  ];

  return (
    <section id="about" className="py-24 relative bg-[#07090E] border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main "What Is Velo Web?" Split Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-24">
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase">
              Brand Identity & Mission
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
              What Is Velo Web?
            </h2>

            <p className="text-lg sm:text-xl text-slate-200 font-medium leading-relaxed">
              Velo Web is a modern website development brand focused on creating professional, responsive, and visually impressive websites.
            </p>

            <p className="text-base text-slate-400 leading-relaxed">
              My goal is simple: take your idea and turn it into a website that looks professional, works smoothly, and represents your business online.
            </p>

            {/* Core Highlights Matrix (Clean unboxed check list) */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {highlights.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Brand Badge Showcase */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center p-8 rounded-2xl bg-[#0B0F17] border border-slate-800 text-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-radial from-cyan-500/10 to-transparent pointer-events-none" />

            {/* Emblem Lockup */}
            <div className="mb-6">
              <VeloLogo size="hero" withWordmark={false} />
            </div>

            <div className="text-2xl font-extrabold text-white mb-1">
              Velo<span className="text-cyan-400">Web</span>
            </div>
            <div className="text-xs text-slate-400 font-medium mb-4">
              Modern Websites. Real Results.
            </div>

            <div className="w-full pt-4 border-t border-slate-800/80 flex items-center justify-around text-xs text-slate-400">
              <div className="text-center">
                <div className="text-white font-semibold">&lt;/&gt;</div>
                <div className="text-[10px] text-slate-500">Web Development</div>
              </div>
              <div className="text-center">
                <div className="text-white font-semibold">100%</div>
                <div className="text-[10px] text-slate-500">Responsive</div>
              </div>
              <div className="text-center">
                <div className="text-white font-semibold">Direct</div>
                <div className="text-[10px] text-slate-500">WhatsApp</div>
              </div>
            </div>
          </div>
        </div>

        {/* "Why Choose Velo Web?" Grid */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
              Why Work With Us
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Why Choose Velo Web?
            </h3>
            <p className="mt-2 text-sm text-slate-400">
              Built on transparency, modern engineering, and zero unnecessary agency layers.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyCards.map((card, i) => (
              <div
                key={i}
                className="rounded-2xl bg-[#0B0F17] border border-slate-800/90 p-6 flex flex-col justify-between hover:border-cyan-500/30 transition-all duration-200"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4">
                    {card.icon}
                  </div>
                  <h4 className="text-base font-bold text-white mb-2">
                    {card.title}
                  </h4>
                  <p className="text-xs text-slate-300 font-medium mb-3">
                    {card.description}
                  </p>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {card.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
