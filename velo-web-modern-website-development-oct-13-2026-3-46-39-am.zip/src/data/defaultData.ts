import { SiteContent } from '../types';

export const initialSiteContent: SiteContent = {
  brand: {
    name: 'Velo Web',
    tagline: 'Modern Website Development',
    positioning: 'Modern Website Development',
    coreMessage: 'You have an idea. Velo Web turns it into a professional website.',
    availability: 'Available for New Projects',
    whatsappNumber: '+92 344 0105980',
    whatsappLink: 'https://wa.me/923440105980',
    instagramHandle: '@_veloweb',
    instagramUrl: 'https://www.instagram.com/_veloweb/',
    facebookName: 'Velo Web',
    facebookUrl: 'https://www.facebook.com/profile.php?id=61595253270239',
    domainPolicyShort: 'Domain purchase & setup available as an optional add-on. Additional charges apply.',
    domainPolicyFull: 'If you already own a domain, I can connect it to your website. If you need a new domain, I can help you purchase and configure one. Domain-related costs and setup charges are separate from the website development price.',
  },
  services: [
    {
      id: 'srv-business',
      title: 'Business Websites',
      tagline: 'Establish authority and trust',
      description: 'Professional websites that help businesses establish a strong online presence and present their offerings clearly.',
      deliverables: ['Multi-page structure', 'Corporate branding integration', 'Service breakdowns', 'Contact & inquiry channels'],
      idealFor: 'Consultancies, corporate firms, professional practices, service providers'
    },
    {
      id: 'srv-landing',
      title: 'Landing Pages',
      tagline: 'High-clarity focused pages',
      description: 'Focused landing pages designed to clearly present a single product, service, or campaign with compelling clarity.',
      deliverables: ['Targeted conversion flow', 'Hero proposition layout', 'Feature showcases', 'Direct lead actions'],
      idealFor: 'Product launches, event campaigns, app releases, targeted offers'
    },
    {
      id: 'srv-portfolio',
      title: 'Portfolio Websites',
      tagline: 'Showcase your work with precision',
      description: 'Modern personal and professional portfolios that showcase creative work, case studies, and specialized skills.',
      deliverables: ['Visual gallery grids', 'Interactive case studies', 'About & credentials sections', 'Direct contact flow'],
      idealFor: 'Designers, architects, developers, creators, consultants'
    },
    {
      id: 'srv-company',
      title: 'Company Websites',
      tagline: 'Complete web presence for organizations',
      description: 'Complete websites for companies, startups, organizations, and growing businesses looking to tell their story.',
      deliverables: ['Multi-section layouts', 'Mission & team presentation', 'Product/solution suites', 'Scalable architecture'],
      idealFor: 'Growing enterprises, tech organizations, institutions, agencies'
    },
    {
      id: 'srv-ecommerce',
      title: 'E-commerce Websites',
      tagline: 'Modern online store experiences',
      description: 'Modern online stores for businesses that want to sell products online with seamless product discovery.',
      deliverables: ['Curated product catalog', 'Interactive cart flows', 'Responsive checkout presentation', 'Category filtering'],
      idealFor: 'Boutiques, direct-to-consumer brands, artisan stores'
    },
    {
      id: 'srv-custom',
      title: 'Custom Websites',
      tagline: 'Tailored solutions for unique ideas',
      description: 'Custom website experiences built around your specific workflow, interactive components, or custom requirements.',
      deliverables: ['Bespoke layout design', 'Custom interactive components', 'API & tool integrations', 'Optimized client workflows'],
      idealFor: 'Startups with unique concepts, specialized tools, bespoke digital products'
    }
  ],
  projects: [
    {
      id: 'proj-apex-advisory',
      title: 'Apex Advisory Partners',
      category: 'Business',
      shortDescription: 'Modern corporate advisory website with executive service sections and responsive structure.',
      fullOverview: 'A sophisticated business advisory web presence engineered for clarity and client trust. Features distinct practice area breakdowns, clean typography, executive bios, and direct inquiry booking.',
      designHighlights: ['Deep slate obsidian palette with subtle cyan hairlines', 'Clear service hierarchy with minimal visual friction', 'High-contrast editorial typography'],
      features: ['Structured service matrices', 'Direct contact & booking routing', 'Mobile-first responsive layout', 'Fast zero-clutter navigation'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
      imageUrl: '/src/assets/images/proj_business_web_1791840256014.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20like%20the%20Apex%20Advisory%20project%20style',
      featured: true
    },
    {
      id: 'proj-aetherflow',
      title: 'AetherFlow Platform',
      category: 'Landing Page',
      shortDescription: 'Cutting-edge tech startup landing page with interactive feature cards and dark studio aesthetics.',
      fullOverview: 'High-impact product landing page built to present a next-generation software platform. Uses dynamic feature cards, high-contrast dark theme, and streamlined conversion triggers.',
      designHighlights: ['Electric cyan aura accents matching tech brand identity', 'Hero focal proposition with balanced typography', 'Asymmetric card flow for feature clarity'],
      features: ['Interactive platform preview', 'Feature comparison blocks', 'Direct WhatsApp demo trigger', 'Mobile-optimized viewport containment'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Motion'],
      imageUrl: '/src/assets/images/proj_startup_saas_1791840287513.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20am%20interested%20in%20a%20landing%20page%20like%20AetherFlow',
      featured: true
    },
    {
      id: 'proj-obscura-dining',
      title: 'Obscura Culinary & Lounge',
      category: 'Business',
      shortDescription: 'Atmospheric artisan dining website with seasonal tasting menu and reservation layout.',
      fullOverview: 'An immersive hospitality website crafted for an artisan restaurant. Prioritizes food imagery, dining hours, location transparency, and frictionless reservation workflows.',
      designHighlights: ['Rich dark background emphasizing photography', 'Refined serif-inspired typography hierarchy', 'Minimal table booking interface'],
      features: ['Interactive seasonal menu viewer', 'Reservation request link to WhatsApp', 'Location & private events section', 'Fluid responsive layout'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS'],
      imageUrl: '/src/assets/images/proj_restaurant_web_1791840271232.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20want%20a%20restaurant%20or%20hospitality%20website%20like%20Obscura',
      featured: true
    },
    {
      id: 'proj-valerius-boutique',
      title: 'Valerius Studio Store',
      category: 'E-commerce',
      shortDescription: 'Minimalist luxury lifestyle and apparel online store with clean product showcase.',
      fullOverview: 'A modern e-commerce storefront focusing on essential product photography, intuitive item navigation, cart drawer preview, and zero-distraction checkout guidance.',
      designHighlights: ['Strict neutral surface contrast', 'Unboxed product cards with generous breathing room', 'Subtle hover states and elegant layout'],
      features: ['Responsive product grid', 'Cart preview drawer state', 'Direct inquiry for bespoke orders', 'Mobile touch-friendly shopping'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS'],
      imageUrl: '/src/assets/images/proj_ecommerce_store_1791840303670.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20am%20looking%20for%20an%20e-commerce%20store%20like%20Valerius',
      featured: true
    },
    {
      id: 'proj-forma-architects',
      title: 'FORMA Architecture Studio',
      category: 'Portfolio',
      shortDescription: 'Monochrome architectural portfolio highlighting selected works, methodology, and studio credentials.',
      fullOverview: 'Clean, gallery-grade portfolio website created for an architectural studio. Uses generous whitespace, clean hairline dividers, and unboxed project metadata to let the work speak.',
      designHighlights: ['High-contrast Swiss architectural layout', 'Tabular index view and photo gallery', 'Zero unnecessary ornamental elements'],
      features: ['Detailed project viewports', 'Studio practice overview', 'Inquiry routing', 'Fast loading optimized layout'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS'],
      imageUrl: '/src/assets/images/proj_creative_portfolio_1791840349714.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20would%20like%20a%20portfolio%20website%20like%20FORMA',
      featured: false
    },
    {
      id: 'proj-aethera-cleanenergy',
      title: 'Aethera Clean Technologies',
      category: 'Company',
      shortDescription: 'Enterprise website for a sustainable energy company with global solutions grid.',
      fullOverview: 'A comprehensive corporate company website designed for an innovative clean-energy enterprise. Highlights industrial scale, technological capabilities, and global presence.',
      designHighlights: ['Futuristic dark UI with subtle electric cyan highlights', 'Structured solutions bento grid', 'Clear corporate storytelling'],
      features: ['Multi-solution category breakdown', 'Enterprise inquiry workflow', 'Fully responsive cross-device layout', 'Clean typographic hierarchy'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS'],
      imageUrl: '/src/assets/images/proj_company_enterprise_1791840365284.jpg',
      liveUrl: 'https://wa.me/923440105980?text=Hi%20Velo%20Web,%20I%20need%20a%20company%20website%20like%20Aethera',
      featured: false
    }
  ],
  packages: [
    {
      id: 'pkg-starter',
      name: 'Starter Website',
      description: 'Ideal for individuals, personal brands, and small businesses establishing a focused online presence.',
      badge: 'Fast Turnaround',
      highlights: [
        'Single-page or focused multi-section landing',
        'Mobile, tablet & desktop responsiveness',
        'Direct WhatsApp & social links integration',
        'Clean, modern typography & dark/light aesthetic',
        'Fast loading & optimized performance'
      ],
      pricingNote: 'Contact Velo Web for a custom quote'
    },
    {
      id: 'pkg-business',
      name: 'Business Website',
      description: 'For businesses and startups requiring a complete, multi-page professional website to represent their company.',
      badge: 'Most Popular',
      highlights: [
        'Complete multi-page website architecture',
        'Dedicated services, about & portfolio sections',
        'Interactive contact & inquiry channels',
        'Modern responsive design matching brand identity',
        'Performance optimization & cross-browser testing'
      ],
      pricingNote: 'Contact Velo Web for a custom quote'
    },
    {
      id: 'pkg-custom',
      name: 'Custom Website',
      description: 'For projects with bespoke requirements, interactive product showcases, e-commerce, or specialized workflows.',
      badge: 'Tailored Solution',
      highlights: [
        'Bespoke layout & unique interactive UI components',
        'E-commerce store or custom web application logic',
        'Third-party tools & API connections',
        'Tailored client workflow & responsive engineering',
        'Full review & launch preparation'
      ],
      pricingNote: 'Contact Velo Web for a custom quote'
    }
  ],
  addOns: [
    {
      id: 'addon-domain-setup',
      title: 'Domain Setup & Connection',
      description: 'Already have a domain? I can connect it to your website.',
      details: 'Configuration of DNS records, nameservers, SSL security certificates, and host verification to ensure your existing domain points seamlessly to your new website.',
      chargeNotice: 'Optional add-on · Additional charges apply'
    },
    {
      id: 'addon-domain-purchase',
      title: 'Domain Purchase Assistance',
      description: 'Need a domain? I can help you purchase and configure one.',
      details: 'Assistance selecting the best available extension (.com, .io, .co, etc.), registrar account setup, purchasing coordination, and technical DNS configuration.',
      chargeNotice: 'Optional add-on · Additional charges apply'
    }
  ],
  faqs: [
    {
      id: 'faq-1',
      question: 'What types of websites do you create?',
      answer: 'Velo Web specializes in business websites, portfolio websites, landing pages, modern company websites, personal websites, product/startup websites, e-commerce stores, and custom web applications. Every project is built from scratch with clean, modern code tailored to your exact idea.'
    },
    {
      id: 'faq-2',
      question: 'Can you build a website for my business?',
      answer: 'Yes. Whether you run a local business, consulting practice, startup, creative studio, or e-commerce brand, Velo Web designs and builds professional websites that present your business clearly and make a trustworthy first impression.'
    },
    {
      id: 'faq-3',
      question: 'Will my website work on mobile?',
      answer: 'Absolutely. Every website built by Velo Web is fully responsive and carefully tested to look and perform smoothly across mobile phones, tablets, laptops, and ultra-wide desktop screens.'
    },
    {
      id: 'faq-4',
      question: 'Can you redesign my existing website?',
      answer: 'Yes. If you already have an outdated or slow website, Velo Web can rebuild it into a fresh, modern, and responsive website while keeping your content and improving the visitor experience.'
    },
    {
      id: 'faq-5',
      question: 'Can you connect my domain?',
      answer: 'Yes. If you already own a domain from any registrar (GoDaddy, Namecheap, Google, Cloudflare, etc.), I can connect and configure it for your new website. Please note that domain setup is an optional add-on service and additional charges apply.'
    },
    {
      id: 'faq-6',
      question: 'Can you purchase a domain for me?',
      answer: 'Yes, Velo Web can assist you with domain research, purchasing, and setup. However, domain purchasing costs and related setup charges are separate from the website development price and are not included in the standard website package.'
    },
    {
      id: 'faq-7',
      question: 'Do you provide SEO or digital marketing?',
      answer: 'No. Velo Web currently focuses specifically on website creation and modern website development rather than SEO, social media marketing, advertising, or copywriting agency services. We build high-quality, professional websites.'
    },
    {
      id: 'faq-8',
      question: 'How do I start a project?',
      answer: 'Starting is quick and simple. Reach out directly on WhatsApp at +92 344 0105980 with your idea, examples of websites you like, or questions. We will discuss your requirements and outline a straightforward plan to build your website.'
    }
  ],
  technologies: [
    'React',
    'TypeScript',
    'Tailwind CSS',
    'Next.js',
    'Vite',
    'Modern HTML5/CSS3',
    'Node.js & Express',
    'Responsive Web Design'
  ]
};
