import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { initialSiteContent } from './data/defaultData';
import { SiteContent } from './types';
import { initGoogleAuth } from './services/googleAuth';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { DomainAddOns } from './components/DomainAddOns';
import { Portfolio } from './components/Portfolio';
import { Process } from './components/Process';
import { About } from './components/About';
import { Packages } from './components/Packages';
import { FAQ } from './components/FAQ';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { AdminCMSModal } from './components/AdminCMSModal';

export default function App() {
  const [content, setContent] = useState<SiteContent>(initialSiteContent);
  const [isCMSOpen, setIsCMSOpen] = useState(false);
  const [hasLoadedFromBackend, setHasLoadedFromBackend] = useState(false);

  // Google Account and OAuth token state
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [googleToken, setGoogleToken] = useState<string | null>(null);

  // Load content from backend database API on startup
  useEffect(() => {
    async function loadBackendContent() {
      try {
        const res = await fetch('/api/content');
        if (res.ok) {
          const data = await res.json();
          if (data && data.brand && data.services) {
            setContent(data);
          }
        }
      } catch (err) {
        console.info('Operating with bundled configuration defaults.', err);
      } finally {
        setHasLoadedFromBackend(true);
      }
    }
    loadBackendContent();

    // Listen to Google Auth state
    const unsubscribe = initGoogleAuth(
      (user, token) => {
        setGoogleUser(user);
        setGoogleToken(token);
      },
      () => {
        setGoogleUser(null);
        setGoogleToken(null);
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Save content to backend database
  const handleSaveContent = async (newContent: SiteContent): Promise<boolean> => {
    setContent(newContent);
    try {
      const res = await fetch('/api/content', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newContent),
      });
      if (res.ok) {
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to sync to backend database:', err);
      // Local state is still updated
      return true;
    }
  };

  // Reset content to default initial configuration
  const handleResetContent = async () => {
    try {
      const res = await fetch('/api/content/reset', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setContent(data.content || initialSiteContent);
      } else {
        setContent(initialSiteContent);
      }
    } catch {
      setContent(initialSiteContent);
    }
  };

  const handleGoogleAuthChange = (user: User | null, token: string | null) => {
    setGoogleUser(user);
    setGoogleToken(token);
  };

  return (
    <div className="min-h-screen bg-[#07090E] text-slate-100 selection:bg-cyan-500/25 selection:text-cyan-300">
      {/* Sticky Navigation */}
      <Navbar
        brand={content.brand}
        onOpenCMS={() => setIsCMSOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* Hero Section */}
        <Hero brand={content.brand} />

        {/* Services Section ("What We Build") */}
        <Services
          services={content.services}
          brand={content.brand}
        />

        {/* Optional Add-Ons ("Optional Website Add-Ons" & Domain Policy) */}
        <DomainAddOns
          addOns={content.addOns}
          brand={content.brand}
        />

        {/* Selected Work / Portfolio Section */}
        <Portfolio
          projects={content.projects}
          brand={content.brand}
          onOpenCMS={() => setIsCMSOpen(true)}
        />

        {/* Process Section ("How It Works") */}
        <Process brand={content.brand} />

        {/* About & Why Choose Velo Web */}
        <About brand={content.brand} />

        {/* Website Packages & Custom Quote */}
        <Packages
          packages={content.packages}
          brand={content.brand}
        />

        {/* Frequently Asked Questions */}
        <FAQ
          faqs={content.faqs}
          brand={content.brand}
        />

        {/* Contact Section & Final CTA */}
        <Contact
          brand={content.brand}
          googleToken={googleToken}
        />
      </main>

      {/* Footer */}
      <Footer
        brand={content.brand}
        onOpenCMS={() => setIsCMSOpen(true)}
      />

      {/* Content Management System (CMS) Modal with Google Sheets Backend */}
      <AdminCMSModal
        isOpen={isCMSOpen}
        content={content}
        onClose={() => setIsCMSOpen(false)}
        onSaveContent={handleSaveContent}
        onResetContent={handleResetContent}
        googleUser={googleUser}
        googleToken={googleToken}
        onGoogleAuthChange={handleGoogleAuthChange}
      />
    </div>
  );
}
