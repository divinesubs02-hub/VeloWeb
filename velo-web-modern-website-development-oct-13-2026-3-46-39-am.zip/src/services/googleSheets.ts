import { SiteContent, Inquiry, Project, Package } from '../types';

export interface SpreadsheetInfo {
  id: string;
  title: string;
  sheets: string[];
  url: string;
}

export const googleSheetsService = {
  // Extract spreadsheet ID from URL or raw ID
  extractSpreadsheetId(input: string): string {
    const trimmed = input.trim();
    const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (match && match[1]) {
      return match[1];
    }
    return trimmed;
  },

  // Fetch spreadsheet metadata to verify connection
  async getSpreadsheetMetadata(accessToken: string, spreadsheetId: string): Promise<SpreadsheetInfo> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${cleanId}?fields=spreadsheetId,properties.title,sheets.properties.title`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `Failed to access spreadsheet (${res.status})`);
    }

    const data = await res.json();
    return {
      id: cleanId,
      title: data.properties?.title || 'Google Sheet',
      sheets: (data.sheets || []).map((s: any) => s.properties?.title),
      url: `https://docs.google.com/spreadsheets/d/${cleanId}/edit`
    };
  },

  // Create a brand new formatted Velo Web Database spreadsheet in Google Drive
  async createVeloSpreadsheet(
    accessToken: string,
    content: SiteContent,
    inquiries: Inquiry[] = []
  ): Promise<SpreadsheetInfo> {
    const createPayload = {
      properties: {
        title: `Velo Web - Live Database Backend (${new Date().toLocaleDateString()})`
      },
      sheets: [
        { properties: { title: 'Brand & Config', tabColor: { red: 0, green: 0.85, blue: 1 } } },
        { properties: { title: 'Projects', tabColor: { red: 0.1, green: 0.6, blue: 0.9 } } },
        { properties: { title: 'Packages', tabColor: { red: 0.2, green: 0.4, blue: 0.8 } } },
        { properties: { title: 'Client Inquiries', tabColor: { red: 0.1, green: 0.8, blue: 0.4 } } }
      ]
    };

    const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(createPayload)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to create Google Spreadsheet');
    }

    const created = await res.json();
    const spreadsheetId = created.spreadsheetId;

    // Seed the spreadsheet tabs with initial data
    await this.syncAllDataToSpreadsheet(accessToken, spreadsheetId, content, inquiries);

    return {
      id: spreadsheetId,
      title: created.properties?.title,
      sheets: ['Brand & Config', 'Projects', 'Packages', 'Client Inquiries'],
      url: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`
    };
  },

  // Sync complete portfolio state into the Google Sheet
  async syncAllDataToSpreadsheet(
    accessToken: string,
    spreadsheetId: string,
    content: SiteContent,
    inquiries: Inquiry[]
  ): Promise<void> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);

    // 1. Prepare Brand & Config Rows
    const brandData = [
      ['Setting / Field', 'Value'],
      ['Brand Name', content.brand.name],
      ['Tagline', content.brand.tagline],
      ['Positioning', content.brand.positioning],
      ['Core Message', content.brand.coreMessage],
      ['Availability', content.brand.availability],
      ['WhatsApp Number', content.brand.whatsappNumber],
      ['WhatsApp Link', content.brand.whatsappLink],
      ['Instagram Handle', content.brand.instagramHandle],
      ['Instagram URL', content.brand.instagramUrl],
      ['Facebook Name', content.brand.facebookName],
      ['Facebook URL', content.brand.facebookUrl],
      ['Domain Policy Short', content.brand.domainPolicyShort],
      ['Domain Policy Full', content.brand.domainPolicyFull],
      ['Last Synced UTC', new Date().toISOString()]
    ];

    // 2. Prepare Projects Rows
    const projectHeaders = ['ID', 'Title', 'Category', 'Short Description', 'Full Overview', 'Technologies', 'Image URL', 'Live URL', 'Featured'];
    const projectRows = content.projects.map(p => [
      p.id,
      p.title,
      p.category,
      p.shortDescription,
      p.fullOverview,
      p.technologies.join(', '),
      p.imageUrl,
      p.liveUrl,
      p.featured ? 'Yes' : 'No'
    ]);
    const projectsData = [projectHeaders, ...projectRows];

    // 3. Prepare Packages Rows
    const packageHeaders = ['ID', 'Name', 'Description', 'Badge', 'Pricing Note', 'Highlights'];
    const packageRows = content.packages.map(pkg => [
      pkg.id,
      pkg.name,
      pkg.description,
      pkg.badge || '',
      pkg.pricingNote,
      pkg.highlights.join(' | ')
    ]);
    const packagesData = [packageHeaders, ...packageRows];

    // 4. Prepare Inquiries Rows
    const inquiryHeaders = ['Inquiry ID', 'Client Name', 'Contact Info', 'Project Type', 'Budget', 'Details', 'Submitted At', 'Status'];
    const inquiryRows = inquiries.map(inq => [
      inq.id,
      inq.name,
      inq.contactMethod,
      inq.projectType,
      inq.budgetRange || '',
      inq.projectDetails,
      inq.createdAt,
      inq.status
    ]);
    const inquiriesData = [inquiryHeaders, ...inquiryRows];

    // Send batchUpdate to fill all tabs
    const batchUpdatePayload = {
      valueInputOption: 'USER_ENTERED',
      data: [
        { range: "'Brand & Config'!A1:B20", values: brandData },
        { range: "'Projects'!A1:I30", values: projectsData },
        { range: "'Packages'!A1:F15", values: packagesData },
        { range: "'Client Inquiries'!A1:H100", values: inquiriesData }
      ]
    };

    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${cleanId}/values:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(batchUpdatePayload)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync data to Google Sheets');
    }
  },

  // Read portfolio data back from Google Sheet into SiteContent
  async readContentFromSpreadsheet(
    accessToken: string,
    spreadsheetId: string,
    currentFallbackContent: SiteContent
  ): Promise<SiteContent> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    const ranges = [
      "'Brand & Config'!A1:B20",
      "'Projects'!A1:I30",
      "'Packages'!A1:F15"
    ];
    const query = ranges.map(r => `ranges=${encodeURIComponent(r)}`).join('&');

    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${cleanId}/values:batchGet?${query}`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to read data from Google Sheets');
    }

    const data = await res.json();
    const valueRanges = data.valueRanges || [];

    const updated = JSON.parse(JSON.stringify(currentFallbackContent)) as SiteContent;

    // Parse Brand & Config
    const brandValues: string[][] = valueRanges[0]?.values || [];
    const brandMap: Record<string, string> = {};
    brandValues.forEach(row => {
      if (row[0] && row[1]) brandMap[row[0].trim()] = row[1].trim();
    });

    if (brandMap['Brand Name']) updated.brand.name = brandMap['Brand Name'];
    if (brandMap['Tagline']) updated.brand.tagline = brandMap['Tagline'];
    if (brandMap['Positioning']) updated.brand.positioning = brandMap['Positioning'];
    if (brandMap['Core Message']) updated.brand.coreMessage = brandMap['Core Message'];
    if (brandMap['Availability']) updated.brand.availability = brandMap['Availability'];
    if (brandMap['WhatsApp Number']) updated.brand.whatsappNumber = brandMap['WhatsApp Number'];
    if (brandMap['WhatsApp Link']) updated.brand.whatsappLink = brandMap['WhatsApp Link'];
    if (brandMap['Instagram Handle']) updated.brand.instagramHandle = brandMap['Instagram Handle'];
    if (brandMap['Instagram URL']) updated.brand.instagramUrl = brandMap['Instagram URL'];
    if (brandMap['Facebook Name']) updated.brand.facebookName = brandMap['Facebook Name'];
    if (brandMap['Facebook URL']) updated.brand.facebookUrl = brandMap['Facebook URL'];
    if (brandMap['Domain Policy Short']) updated.brand.domainPolicyShort = brandMap['Domain Policy Short'];
    if (brandMap['Domain Policy Full']) updated.brand.domainPolicyFull = brandMap['Domain Policy Full'];

    // Parse Projects
    const projectRows: string[][] = valueRanges[1]?.values || [];
    if (projectRows.length > 1) {
      const parsedProjects: Project[] = [];
      // Skip header row
      for (let i = 1; i < projectRows.length; i++) {
        const row = projectRows[i];
        if (!row || !row[1]) continue;
        parsedProjects.push({
          id: row[0] || `proj-${Date.now()}-${i}`,
          title: row[1],
          category: (row[2] as any) || 'Business',
          shortDescription: row[3] || '',
          fullOverview: row[4] || row[3] || '',
          technologies: row[5] ? row[5].split(',').map(t => t.trim()).filter(Boolean) : ['React', 'Tailwind CSS'],
          imageUrl: row[6] || '/src/assets/images/hero_web_mockup_1791840238520.jpg',
          liveUrl: row[7] || updated.brand.whatsappLink,
          featured: row[8]?.toLowerCase() === 'yes',
          designHighlights: ['Modern clean layout', '100% Responsive design', 'Dark studio theme'],
          features: ['Fast loading', 'Direct WhatsApp inquiry']
        });
      }
      if (parsedProjects.length > 0) {
        updated.projects = parsedProjects;
      }
    }

    // Parse Packages
    const packageRows: string[][] = valueRanges[2]?.values || [];
    if (packageRows.length > 1) {
      const parsedPackages: Package[] = [];
      for (let i = 1; i < packageRows.length; i++) {
        const row = packageRows[i];
        if (!row || !row[1]) continue;
        parsedPackages.push({
          id: row[0] || `pkg-${i}`,
          name: row[1],
          description: row[2] || '',
          badge: row[3] || undefined,
          pricingNote: row[4] || 'Contact Velo Web for a custom quote',
          highlights: row[5] ? row[5].split('|').map(h => h.trim()).filter(Boolean) : ['Responsive Website', 'WhatsApp Integration']
        });
      }
      if (parsedPackages.length > 0) {
        updated.packages = parsedPackages;
      }
    }

    return updated;
  },

  // Append single new client inquiry directly into Google Sheet
  async appendInquiryToSpreadsheet(
    accessToken: string,
    spreadsheetId: string,
    inquiry: Inquiry
  ): Promise<void> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    const row = [
      inquiry.id,
      inquiry.name,
      inquiry.contactMethod,
      inquiry.projectType,
      inquiry.budgetRange || '',
      inquiry.projectDetails,
      inquiry.createdAt,
      inquiry.status
    ];

    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${cleanId}/values/'Client Inquiries'!A:H:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [row] })
    });

    if (!res.ok) {
      console.warn('Could not append inquiry to Google Sheet:', await res.text());
    }
  }
};
