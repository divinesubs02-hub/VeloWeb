import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { initialSiteContent } from './src/data/defaultData.ts';
import { SiteContent, Inquiry } from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Ensure database data directory exists
const DATA_DIR = path.resolve(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const CONTENT_FILE = path.join(DATA_DIR, 'content.json');
const INQUIRIES_FILE = path.join(DATA_DIR, 'inquiries.json');

// Initialize database files if not present
if (!fs.existsSync(CONTENT_FILE)) {
  fs.writeFileSync(CONTENT_FILE, JSON.stringify(initialSiteContent, null, 2), 'utf-8');
}

if (!fs.existsSync(INQUIRIES_FILE)) {
  const initialInquiries: Inquiry[] = [
    {
      id: 'inq-welcome',
      name: 'Velo Web System',
      contactMethod: '+92 344 0105980',
      projectType: 'Business Website',
      budgetRange: 'Custom Quote',
      projectDetails: 'Welcome to Velo Web Content Management! Client inquiries from the contact modal appear here automatically.',
      createdAt: new Date().toISOString(),
      status: 'new'
    }
  ];
  fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(initialInquiries, null, 2), 'utf-8');
}

function getContent(): SiteContent {
  try {
    const raw = fs.readFileSync(CONTENT_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading content database, falling back to defaults', err);
    return initialSiteContent;
  }
}

function getInquiries(): Inquiry[] {
  try {
    const raw = fs.readFileSync(INQUIRIES_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading inquiries database', err);
    return [];
  }
}

// API Routes
app.get('/api/content', (_req, res) => {
  res.json(getContent());
});

app.put('/api/content', (req, res) => {
  try {
    const updatedContent = req.body as SiteContent;
    fs.writeFileSync(CONTENT_FILE, JSON.stringify(updatedContent, null, 2), 'utf-8');
    res.json({ success: true, message: 'Content saved successfully', content: updatedContent });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to save content' });
  }
});

app.post('/api/content/reset', (_req, res) => {
  try {
    fs.writeFileSync(CONTENT_FILE, JSON.stringify(initialSiteContent, null, 2), 'utf-8');
    res.json({ success: true, message: 'Content reset to defaults', content: initialSiteContent });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/inquiries', (_req, res) => {
  res.json(getInquiries());
});

app.post('/api/inquiries', (req, res) => {
  try {
    const { name, contactMethod, projectType, budgetRange, projectDetails } = req.body;
    if (!name || !contactMethod || !projectDetails) {
      return res.status(400).json({ error: 'Name, contact method, and details are required' });
    }

    const inquiries = getInquiries();
    const newInquiry: Inquiry = {
      id: `inq-${Date.now()}`,
      name,
      contactMethod,
      projectType: projectType || 'General Inquiry',
      budgetRange: budgetRange || 'Standard',
      projectDetails,
      createdAt: new Date().toISOString(),
      status: 'new'
    };

    inquiries.unshift(newInquiry);
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(inquiries, null, 2), 'utf-8');
    res.status(201).json({ success: true, inquiry: newInquiry });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to log inquiry' });
  }
});

app.patch('/api/inquiries/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const inquiries = getInquiries();
    const target = inquiries.find(i => i.id === id);
    if (!target) return res.status(404).json({ error: 'Inquiry not found' });
    
    if (status) target.status = status;
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(inquiries, null, 2), 'utf-8');
    res.json({ success: true, inquiry: target });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/inquiries/:id', (req, res) => {
  try {
    const { id } = req.params;
    const inquiries = getInquiries().filter(i => i.id !== id);
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(inquiries, null, 2), 'utf-8');
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Velo Web server running on http://0.0.0.0:${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer();
